// Développeur : Limule Hinugera
require("./all/global");

const func = require("./all/place");
const readline = require("readline");
const yargs = require('yargs/yargs');
const _ = require('lodash');
const usePairingCode = true;

/**
 * Fonction pour poser une question à l'utilisateur via la console.
 * @param {string} text - Le texte de la question à afficher.
 * @returns {Promise<string>} - Une promesse résolue avec la réponse de l'utilisateur.
 */
const question = (text) => {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise((resolve) => {
    rl.question(text, resolve);
  });
};

/**
 * Fonction principale pour démarrer la session WhatsApp.
 */
async function startSesi() {
  const store = makeInMemoryStore({
    logger: pino().child({
      level: 'silent',
      stream: 'store'
    })
  });
  const {
    state,
    saveCreds
  } = await useMultiFileAuthState(`./session`);
  const {
    version,
    isLatest
  } = await fetchLatestBaileysVersion();

  console.log(chalk.blue.bold(`
✨ BIENVENUE ! ✨

${chalk.yellow.bold(`
🤖 VERSION DU BOT : 1.0`)}
${chalk.magenta.bold(`
🔥 PREMIÈRE GÉNÉRATION`)}
${chalk.green.bold("ℹ️ INFORMATION :")}
${chalk.red.bold(`
🌟 Description : 🍒WHATSAPP BOT🍒
🌟 Auteur : CRAZY DEV
🌟 Nom du bot : DEATH_CRAZY
`)}
${chalk.white.italic("✨ Propulsé par Crazy Dev ✨")}\n`));

  const connectionOptions = {
    version,
    keepAliveIntervalMs: 30000,
    printQRInTerminal: !usePairingCode,
    logger: pino({
      level: "fatal"
    }),
    auth: state,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    getMessage: async (key) => {
      if (store) {
        const msg = await store.loadMessage(key.remoteJid, key.id, undefined);
        return msg?.message || undefined;
      }
      return {
        conversation: 'Crazy Crash by Crazy Dev.'
      };
    }
  };

  const lubyz = func.makeWASocket(connectionOptions);
  if (usePairingCode && !lubyz.authState.creds.registered) {
    const phoneNumber = await question(color('Veuillez entrer votre numéro sans le plus (+) (ex: 241xxx) : ', 'green'));
    const code = await lubyz.requestPairingCode(phoneNumber.trim());
    console.log(`${chalk.redBright('Votre code de jumelage :')} ${code}`);
  }
  store?.bind(lubyz.ev);

  lubyz.ev.on('connection.update', async (update) => {
    const {
      connection,
      lastDisconnect
    } = update;
    if (connection === 'close') {
      const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
      console.log(color(lastDisconnect.error, 'deeppink'));
      if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
        process.exit();
      } else if (reason === DisconnectReason.badSession) {
        console.log(color(`Fichier de session corrompu, veuillez supprimer la session et scanner à nouveau`));
        process.exit();
      } else if (reason === DisconnectReason.connectionClosed) {
        console.log(color('[SYSTEM]', 'white'), color('Connexion fermée, reconnexion en cours...', 'deeppink'));
        process.exit();
      } else if (reason === DisconnectReason.connectionLost) {
        console.log(color('[SYSTEM]', 'white'), color('Connexion perdue, tentative de reconnexion...', 'deeppink'));
        process.exit();
      } else if (reason === DisconnectReason.connectionReplaced) {
        console.log(color('Connexion remplacée, une autre session a été ouverte. Veuillez fermer la session actuelle.'));
        lubyz.logout();
      } else if (reason === DisconnectReason.loggedOut) {
        console.log(color(`Déconnecté. Veuillez scanner à nouveau et exécuter.`));
        lubyz.logout();
      } else if (reason === DisconnectReason.restartRequired) {
        console.log(color('Redémarrage requis, redémarrage en cours...'));
        await startSesi();
      } else if (reason === DisconnectReason.timedOut) {
        console.log(color('Délai de connexion dépassé, reconnexion en cours...'));
        startSesi();
      }
    } else if (connection === "connecting") {
      console.log(color('CONNEXION EN COURS... ⚙️'));
    } else if (connection === "open") {
      let teksnotif = `✨ HI CREATOR ✨

✅ *La connexion de votre Bot a réussi !* ✅

🤖 *Nom du Bot :* ${global.namabot2}
🚀 *Version :* \`1.0.0\`
📱 *Numéro :* ${lubyz.user.id.split(":")[0]}

✨ Merci d'avoir choisi Crazy crash 🍒`;
      lubyz.sendMessage(global.owner + "@s.whatsapp.net", {
        text: teksnotif
      });
      console.log(color(`Le bot s'est connecté avec succès. Merci pour votre travail ✨`));
    }
  });

  lubyz.ev.on('call', async (user) => {
    if (!global.anticall) return;
    for (let ff of user) {
      if (ff.isGroup == false) {
        if (ff.status == "offer") {
          let sendcall = await lubyz.sendMessage(ff.from, {
            text: `@${ff.from.split("@")[0]} 🚫 Désolé, je vais vous bloquer si vous essayez de m'appeler. *ANTICALL ACTIVÉ* 🚫\nSi vous avez contacté le propriétaire accidentellement, vous serez débloqué immédiatement.`,
            contextInfo: {
              mentionedJid: [ff.from],
              externalAdReply: {
                showAdAttribution: true,
                thumbnail: fs.readFileSync("./media/warning.jpg"),
                title: "🚨 Appel Détecté 🚨",
                previewType: "PHOTO"
              }
            }
          }, {
            quoted: null
          });
          lubyz.sendContact(ff.from, [owner], "Développeur du Bot WhatsApp", sendcall);
          await sleep(10000);
          await lubyz.updateBlockStatus(ff.from, "block");
        }
      }
    }
  });

  lubyz.ev.on('messages.upsert', async (chatUpdate) => {
    try {
      m = chatUpdate.messages[0];
      if (!m.message) return;
      m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message;
      if (m.key && m.key.remoteJid === 'status@broadcast') return lubyz.readMessages([m.key]);
      if (!lubyz.public && m.key.remoteJid !== global.owner + "@s.whatsapp.net" && !m.key.fromMe && chatUpdate.type === 'notify') return;
      if (m.key.id.startsWith('BAE5') && m.key.id.length === 16) return;
      if (global.autoread) lubyz.readMessages([m.key]);
      m = func.smsg(lubyz, m, store);
      require("./CRAZY_CRASH-V1.js")(lubyz, m, store);
    } catch (err) {
      console.log(err);
    }
  });

  lubyz.ev.on('group-participants.update', async (anu) => {
    if (!global.welcome) return;
    let botNumber = await lubyz.decodeJid(lubyz.user.id);
    if (anu.participants.includes(botNumber)) return;
    try {
      let metadata = await lubyz.groupMetadata(anu.id);
      let namagc = metadata.subject;
      let participants = anu.participants;
      for (let num of participants) {
        let check = anu.author !== num && anu.author.length > 1;
        let tag = check ? [anu.author, num] : [num];
        try {
          ppuser = await lubyz.profilePictureUrl(num, 'image');
        } catch {
          ppuser = 'https://files.catbox.moe/ec2176/CRAZY_CRASH_V1.jpg';
        }
        if (anu.action == 'add') {
          lubyz.sendMessage(anu.id, {
            text: check ? `@${anu.author.split("@")[0]} ➕ *a ajouté* @${num.split("@")[0]} *dans ce groupe* 🎉\n\n👋 Bonjour @${num.split("@")[0]} ! Bienvenue dans *${namagc}*` : `👋 Bonjour @${num.split("@")[0]} ! Bienvenue dans *${namagc}* 🎉`,
            contextInfo: {
              mentionedJid: [...tag],
              externalAdReply: {
                thumbnailUrl: ppuser,
                title: '🎉 Message de Bienvenue 🎉\n\n✨ Propulsé par CRAZY DEV ✨',
                body: '',
                renderLargerThumbnail: true,
                sourceUrl: linkgc,
                mediaType: 1
              }
            }
          });
        }
        if (anu.action == 'remove') {
          lubyz.sendMessage(anu.id, {
            text: check ? `@${anu.author.split("@")[0]} ➖ *a supprimé* @${num.split("@")[0]} *de ce groupe* 😔` : `@${num.split("@")[0]} *a quitté ce groupe* 😔`,
            contextInfo: {
              mentionedJid: [...tag],
              externalAdReply: {
                thumbnailUrl: ppuser,
                title: '😔 Message d\'Au Revoir 😔\n\n✨ Propulsé par CRAZY DEV ✨',
                body: '',
                renderLargerThumbnail: true,
                sourceUrl: linkgc,
                mediaType: 1
              }
            }
          });
        }
        if (anu.action == "promote") {
          lubyz.sendMessage(anu.id, {
            text: `@${anu.author.split("@")[0]} 👑 *a promu* @${num.split("@")[0]} *en tant qu'administrateur de ce groupe* 👑`,
            contextInfo: {
              mentionedJid: [...tag],
              externalAdReply: {
                thumbnailUrl: ppuser,
                title: '👑 Message de Promotion 👑\n\n✨ Propulsé par CRAZY DEV ✨',
                body: '',
                renderLargerThumbnail: true,
                sourceUrl: linkgc,
                mediaType: 1
              }
            }
          });
        }
        if (anu.action == "demote") {
          lubyz.sendMessage(anu.id, {
            text: `@${anu.author.split("@")[0]} ⚔️ *a rétrogradé* @${num.split("@")[0]} *de son rôle d'administrateur dans ce groupe* ⚔️`,
            contextInfo: {
              mentionedJid: [...tag],
              externalAdReply: {
                thumbnailUrl: ppuser,
                title: '⚔️ Message de Rétrogradation ⚔️\n\n✨ Propulsé par CRAZY DEV ✨',
                body: '',
                renderLargerThumbnail: true,
                sourceUrl: linkgc,
                mediaType: 1
              }
            }
          });
        }
      }
    } catch (err) {
      console.log(err);
    }
  });

  lubyz.public = true;

  lubyz.ev.on('creds.update', saveCreds);
  return lubyz;
}

startSesi();

process.on('uncaughtException', function(err) {
  console.log('Exception non gérée : ', err);
});

// Module d'exportation pour la gestion des messages
module.exports = async (lubyz, m, store) => {
  try {
    // Extraction des données du message
    const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype === 'imageMessage') ? m.message.imageMessage.caption : (m.mtype === 'videoMessage') ? m.message.videoMessage.caption : (m.mtype === 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype === 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype === 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype === 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : '';
    const budy = (typeof m.text == 'string' ? m.text : '');
    const prefix = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi) : '/';
    const isCmd = body.startsWith(prefix);
    const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
    const args = body.trim().split(/ +/).slice(1);
    const q = args.join(' ');
    const isGroup = m.chat.endsWith('@g.us');
    const sender = m.sender;
    const pushname = m.pushName;
    const isOwner = owner.includes(sender)
    const isPrem = prem.includes(sender)
    const groupMetadata = isGroup ? await lubyz.groupMetadata(m.chat).catch(e => {}) : ''
    const groupName = isGroup ? groupMetadata.subject : ''
    const participants = isGroup ? await groupMetadata.participants : ''
    const groupAdmins = isGroup ? getGroupAdmins(participants) : ''
    const isBotAdmin = isGroup ? groupAdmins.includes(botNumber) : false
    const isAdmin = isGroup ? groupAdmins.includes(sender) : false
    const isMedia = (type === 'imageMessage' || type === 'videoMessage')
    const isQuotedMsg = (type === 'extendedTextMessage') && content.includes('Message')
    const isQuotedImage = (type === 'extendedTextMessage') && content.includes('imageMessage')
    const isQuotedVideo = (type === 'extendedTextMessage') && content.includes('videoMessage')
    const isQuotedSticker = (type === 'extendedTextMessage') && content.includes('stickerMessage')

    // Fonctions utiles
    const reply = (teks) => {
      lubyz.sendMessage(m.chat, {
        text: teks
      }, {
        quoted: m
      })
    }

    const sendContact = (jid, numbers, name, quoted, mn) => {
      let number = numbers.replace(/[^0-9]/g, '')
      const vcard = 'BEGIN:VCARD\n' +
        'VERSION:3.0\n' +
        'FN:' + name + '\n' +
        'ORG:;\n' +
        'TEL;type=CELL;type=VOICE;waid=' + number + ':' + number + '\n' +
        'END:VCARD'
      lubyz.sendMessage(jid, {
        contacts: {
          displayName: name,
          contacts: [{
            vcard
          }]
        },
        mentions: mn ? mn : []
      }, {
        quoted: quoted
      })
    }

    const sendImage = async (jid, path, caption = '', quoted = '', options) => {
      let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,(.*)$/i.exec(path) ? Buffer.from(RegExp.$1, 'base64') : /^https?:\/\//i.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
      return await lubyz.sendMessage(jid, {
        image: buffer,
        caption: caption,
        ...options
      }, {
        quoted
      })
    }

    const sendVideo = async (jid, path, caption = '', quoted = '', gif = false, options) => {
      let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,(.*)$/i.exec(path) ? Buffer.from(RegExp.$1, 'base64') : /^https?:\/\//i.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
      return await lubyz.sendMessage(jid, {
        video: buffer,
        caption: caption,
        gifPlayback: gif,
        ...options
      }, {
        quoted
      })
    }

    const sendAudio = async (jid, path, quoted = '', ptt = true, options) => {
      let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,(.*)$/i.exec(path) ? Buffer.from(RegExp.$1, 'base64') : /^https?:\/\//i.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
      return await lubyz.sendMessage(jid, {
        audio: buffer,
        ptt: ptt,
        ...options
      }, {
        quoted
      })
    }

    const sendText = (jid, text, quoted = '', options) => lubyz.sendMessage(jid, {
      text: text,
      ...options
    }, {
      quoted: quoted
    })

    const sendSticker = async (jid, path, quoted = '', options) => {
      let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,(.*)$/i.exec(path) ? Buffer.from(RegExp.$1, 'base64') : /^https?:\/\//i.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
      return await lubyz.sendMessage(jid, {
        sticker: buffer,
        ...options
      }, {
        quoted
      })
    }

    const isUrl = (url) => {
      return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/, 'gi'))
    }

    function getGroupAdmins(participants) {
      admins = []
      for (let i of participants) {
        i.admin === "superadmin" ? admins.push(i.id) : i.admin === "admin" ? admins.push(i.id) : ''
      }
      return admins || []
    }
    // Gestionnaire de commandes
    switch (command) {
      case 'ping':
        reply('Pong!')
        break;
        // Ajoutez d'autres commandes ici
      default:
        if (isCmd) {
          reply(`Commande non reconnue.`)
        }
    }
  } catch (err) {
    console.error(err);
    lubyz.sendMessage(owner + "@s.whatsapp.net", {
      text: `Erreur : ${util.format(err)}`
    });
  }
};
//Améliorations apportées : 

// •   Commentaires :  Ajout de commentaires pour expliquer le code.
// •   Organisation :  Amélioration de l'organisation du code pour une meilleure lisibilité.
