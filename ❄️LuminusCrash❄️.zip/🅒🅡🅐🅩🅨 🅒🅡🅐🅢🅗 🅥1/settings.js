

require("./all/module.js")
const { color } = require('./all/function')
const { version } = require("./package.json")


//========== Setting Owner ==========//
global.owner = "24165730123"
global.owner2 = "24166120635"
global.namaowner = "𝗖𝗥𝗔𝗭𝗬 𝗗𝗘𝗩"
global.botname = "𝗗𝗘𝗔𝗧𝗛_𝗖𝗥𝗔𝗭𝗬"


//======== Setting Bot & Link ========//
global.namabot = "🕸️𝗗𝗘𝗔𝗧𝗛_𝗖𝗥𝗔𝗭𝗬🕸️" 
global.namabot2 = "🕷️𝗖𝗥𝗔𝗭𝗬_𝗕𝗥𝗨𝗧𝗔𝗟𝗜𝗧𝗬🕷️"
global.foother = "𝗖𝗥𝗔𝗭𝗬 𝗗𝗘𝗩🍃"
global.versibot = "𝟭.𝟬"
global.idsaluran = false
global.linkgc = 'https://whatsapp.com/channel/0029Vb4QhPj4NVipeOtyo02n'
global.linksaluran = 'https://whatsapp.com/channel/0029Vb4QhPj4NVipeOtyo02n'
global.linkyt = 'https://youtube.com/@none'
global.linktele = 'https://t.me/CRAZY_OFC'
global.packname = "𝗗𝗘𝗔𝗗..🚫 𝗕𝗬"
global.author = "C⃟R⃟A⃟Z⃟Y⃟⚠️"

//========== Setting Event ==========//
global.welcome = true
global.autoread = false
global.anticall = true
global.owneroff = false


//========== Setting Panel Server  1==========//
global.domain = ""
global.apikey = ""
global.capikey = ""
//======== egg & loc biasanya sama jadi gausah ========//
global.egg = "15"
global.loc = "1"

//========= Setting Message =========//
global.msg = {
"error": "*🎭 Une erreur est survenue.*",
"done": "*Fait avec succès ✅*", 
"wait": "*Le processus est en cours...⏳*", 
"group": "*Cette commande n'est permise uniquement sur un chat de groupe.😥*", 
"private": "Cette commande n'est permise uniquement sur un chat privé.🙂*", 
"admin": "*Seul un administrateur a droit à cette commande.🤷*", 
"adminbot": "*Cette commande ne peut être exécutée si seulement Crazy est admin du groupe.👷*", 
"owner": "*Réservée à mon owner uniquement.🙇*", 
"developer": "*Seulement les dev peuvent en avoir accès.👻*", 
"premium": "*Réservée à l'équipe premium  uniquement.👩‍💻*"

}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})